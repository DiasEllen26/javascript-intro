console.log(typeof 5);
console.log(typeof 12.5);
console.log(typeof "Dennycreidsson");