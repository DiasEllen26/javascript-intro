console.log(2 + 3);
console.log(5 - 3);
console.log(5 * 3);
console.log(5 / 3);

console.log(21 % 2); 

console.log(20 % 2);

console.log(typeof(2 + 3));

console.log(typeof(5 - 3));