x = 24;
while(x > 0){
    console.log('produto ' + x);
    x--;
}


while( x <= 10){
    console.log('O valor é ' + x);
    x++;
}
