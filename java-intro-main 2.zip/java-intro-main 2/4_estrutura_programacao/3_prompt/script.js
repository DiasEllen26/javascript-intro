idade = prompt("Qual sua idade parceirão?");

console.log('Sua idade é ' + idade);

nome = prompt('Qual seu nome?');

console.log('Olá ' + nome + ' sua idade é ' + idade);
