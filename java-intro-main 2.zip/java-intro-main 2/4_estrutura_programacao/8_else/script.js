velocidade = 170;

if(velocidade <= 40){
    console.log('Parabéns');
}else if((velocidade > 40) && (velocidade < 45)){
    console.log('Atenção!');
}else{
    console.log('Perigo!');
}