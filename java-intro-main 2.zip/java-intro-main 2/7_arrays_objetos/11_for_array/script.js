// for([inicialização]; [condicao]; [expressao final] )/{
//  declaração
//}
nomes = ['Juviliano', 'Bill', 'Denycriedson'];

for (let i = 0; i <= nomes.length; i++) {
    console.log(nomes[i]); //0 1 2

}
