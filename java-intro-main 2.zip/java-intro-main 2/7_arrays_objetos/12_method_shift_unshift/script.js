//adiciona e remove do final
nomes = ['Juvialiano', 'Bill']

console.log(nomes.shift());

console.log(nomes);

console.log(nomes.unshift('Izabel', 'rip'))

console.log(nomes);