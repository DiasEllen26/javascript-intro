
marca = 'nike';

console.log(marca.toUpperCase());
//maiusculo

marca2 = marca.toUpperCase();

console.log(marca2.toLowerCase());
//minuscula

//string.propriedade
//string.metodo()
