num = [0,2,3,4,5,6];

console.log(num.slice(4,5));
//trás a posicação 4 porque ele para uma posição antes

console.log(num.slice(4,6));

console.log(num.slice(2));
//trás a partir da posição 

console.log(num.slice(-2));
//pega apenas os 2 ultimos

console.log(num.slice(-1,-2))
//pega do 1 e deixa os dois ultimos fora 
