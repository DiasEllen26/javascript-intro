//objeto
cachorro = {
    //propriedades
    cor: 'Caramelo',
    patas: 4,
    nome: 'Cavalo',
    //metodo
    latir: function(){
        console.log('miau');
    }
    
}
cachorro.latir();
console.log(cachorro.patas)
console.log(cachorro.cor)
console.log(cachorro.nome)
