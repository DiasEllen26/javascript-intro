nomes = ['Juvelino', 'Josivaldo']

elementoRemovido = nomes.pop();

console.log(elementoRemovido);

console.log(nomes);

nomes.push('fião');

console.log(nomes);