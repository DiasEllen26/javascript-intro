nome = ["Biruleibe", 'pixuruca', 'Josémaria', 'mariajose']

nome.forEach(x => { 
    console.log('Bos estudos x' + x)
    
});